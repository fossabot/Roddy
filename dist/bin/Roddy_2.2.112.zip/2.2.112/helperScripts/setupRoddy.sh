#!/bin/bash

# Create a roddyProject folder at the set location




# Ask for the project out folder

